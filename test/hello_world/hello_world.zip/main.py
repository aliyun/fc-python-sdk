def my_handler(event, context):
        return 'hello world'
